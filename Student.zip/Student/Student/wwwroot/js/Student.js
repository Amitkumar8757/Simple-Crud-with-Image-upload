﻿
$(document).ready(function () {
    void loadData();

});
function loadData() {
    $.ajax({
        url: 'Student/GetStudent',
        type: "GET",
        dataType: "json",
        success: function (result) {
            var html = '';
            
            $.each(result, function (key, item) {
                
                   html += '<tr>';
                   html += '<td class=id >' + item.id + '</td>';
                   html += '<td><span class="spanshow">' + item.name + '</span><input type="text" id="Name" class="inputhide Name" value="' + item.name + '" /></td>';
                   html += '<td><span class="spanshow">' + item.email + '</span><input type="text" class="inputhide Email" value="' + item.email + '" /></td>';
                   html += '<td><span class="spanshow">' + item.mobile + '</span><input type="text" class="inputhide Mobile" value="' + item.mobile + '" /></td>';
                   html += '<td><span class="spanshow">' + item.address + '</span><input type="text" class="inputhide Address" value="' + item.address + '" /></td>';

                   html += '<td><a mainId="' + item.id + '" class=" edit btn btn-sm btn-primary btnEditsmain">Edit</a> <a style="display:none;" onclick="update(' + item.id + ')" class="  btn btn-sm btn-primary btnupdatemain">update</a> <a style="display:none;" onclick="cancel(' + item.id + ')" class="  btn btn-sm btn-secondary btncancelmain">Cancel</a> | <a onclick="Delete(' + item.id + ')" class="btn btn-sm btn-danger">Delete</a></td>';
                   html += '</tr>';
                  
                   });
           
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}
               // DELETE ROW
function Delete(Id) {
    if (confirm("Are you sure, You want to delete this Record?")) {
        //debugger
        $.ajax({
            url: 'Student/DeleteStudent?id=' + Id,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            success: function () {

                alert('Record is Successfully Removed in Database!');
                loadData();
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }
}
$(document).on("click", ".btnEditsmain", function () {
    var Button = $(this);
    var ButtonID = $(Button).attr("mainId");
    $(Button).parent().parent().find(".spanshow").hide();
    $(Button).parent().parent().find(".inputhide").show();
    $(Button).hide();
    $(Button).parent().parent().find(".btnupdatemain").show();
});

function update() {
    debugger;
    var obj = {
        /*Id: parseInt($(this).attr("id")),*/
        Id: parseInt$('.id').val(),
        Name: $('.Name').val(),
        Email: $('.Email').val(),
        Mobile: $(".Mobile").val(),
        Address: $(".Address").val()
    };
    debugger;
    $.ajax({
        url: 'Student/UpdateStudent',
        data: JSON.stringify(obj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        success: function () {
            loadData();
          
            $('.Name').val("");
            $('.Email  ').val("");
            $('.Mobile').val("");
            $('.Address').val("");
            swal('Record Updated!');
        },

        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });

};







function validate() {
    var isValid = true;
    if ($('#name').val().trim() == "") {
        $('#name').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#name').css('border-color', 'lightgrey');
    }
    if ($('#email').val().trim() == "") {
        $('#email').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#email').css('border-color', 'lightgrey');
    }
    if ($('#mobile').val().trim() == "") {
        $('#mobile').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#mobile').css('border-color', 'lightgrey');
    }
    if ($('#address').val().trim() == "") {
        $('#address').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#address').css('border-color', 'lightgrey');
    }
   
    
    return isValid;
}
    