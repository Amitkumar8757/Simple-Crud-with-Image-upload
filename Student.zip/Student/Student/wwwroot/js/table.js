﻿$('#myTableId').DataTable({
    dom: 'Bfrtip',
    data: dataSource,
    columns: [
        {
            render: function (data, type, row, meta) {
                return meta.row + meta.settings._iDisplayStart + 1;
            }
        },
        { data: 'name class: 'editable text' },
        { data: 'email' },
        { data: 'mobile' },
        { data: 'address' },
        {
            //edit button creation    
            render: function (data, type, row) {
                return createButton('edit', row.id);
            }
        },
        {
            //delete button creation    
            render: function (data, type, row) {
                return createButton('delete', row.id);
            }
        }
    ],
    "searching": false,
    "paging": true,
    "info": true,
    "language": {
        "emptyTable": "No data available"
    },
    "fnRowCallback": function (nRow, aData, iDisplayIndex) {
        $("td:first", nRow).html(iDisplayIndex + 1);
        return nRow;
    },
})