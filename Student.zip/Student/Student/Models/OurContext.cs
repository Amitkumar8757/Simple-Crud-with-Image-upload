﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Student.Models
{
    public class OurContext:DbContext
    {
        public OurContext(DbContextOptions<OurContext> options) : base(options) { }
        public DbSet<StudentModel> Students { get; set; }
        public DbSet<Employee> Employee { get; set; }
    }
}
