﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Student.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Student.Controllers
{
    public class StudentController : Controller
    {
        private readonly OurContext dbcontext;
        public StudentController(OurContext _dbcontext)
        {
            dbcontext = _dbcontext;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetStudent(int? id)
        {
            var Stud = dbcontext.Students.ToList();
            if (id != null)
            {
                Stud = Stud.Where(x => x.Id == id).ToList();
            }
            return new JsonResult(Stud);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(StudentModel stud)
        {
            if (!ModelState.IsValid)
            {
                return new JsonResult("input field can't be empty");
            }
            dbcontext.Students.Add(stud);
            dbcontext.SaveChanges();
            return new JsonResult(stud);
        }


        [HttpPost]
        public IActionResult UpdateStudent( StudentModel obj)
        {
            StudentModel stud = (from c in dbcontext.Students
                            where c.Id == obj.Id
                            select c).FirstOrDefault();

            stud.Name = obj.Name;
            stud.Email = obj.Email;
            stud.Mobile = obj.Mobile;
            stud.Address = obj.Address;
            
            dbcontext.Update(stud);
            dbcontext.SaveChanges();
            return new JsonResult(stud);
        }

        [HttpPost]
        public ActionResult DeleteStudent(int id)
        {
            StudentModel stud = (from c in dbcontext.Students
                             where c.Id == id
                             select c).FirstOrDefault();
            dbcontext.Students.Remove(stud);
            dbcontext.SaveChanges();

            return new EmptyResult();
        }
    }
}
